import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { Observable, forkJoin } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'www';
  numbers = '';

  constructor(private http: HttpClient) { }

  doIt(): void {
    const requests = Array(10).fill(1).map(n => this.getNumber());
    forkJoin(requests)
      .subscribe(
        r => this.numbers = r.join(','),
        e => console.error(e)
      );
  }

  private getNumber(): Observable<number> {
    return this.http.get<number>('http://localhost:8000/num');
  }
}
