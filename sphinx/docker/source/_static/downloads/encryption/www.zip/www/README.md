# www

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 12.2.4.

## Docker

```bash
docker build -t www:local .
docker run --rm -p 4200:80 www:local

docker tag www:local localhost:5000/www:latest
docker image push localhost:5000/www:latest
docker rmi localhost:5000/www:latest

sudo ctr-enc images pull --plain-http=true --all-platforms localhost:5000/www:latest
sudo ctr-enc images layerinfo --platform linux/amd64 localhost:5000/www:latest

sudo ctr-enc images encrypt --recipient jwe:public.pem --platform linux/amd64 localhost:5000/www:latest localhost:5000/www.enc:latest
sudo ctr-enc images layerinfo --platform linux/amd64 localhost:5000/www.enc:latest

sudo nerdctl run --rm -p 4200:80 localhost:5000/www.enc:latest

sudo nerdctl save localhost:5000/www.enc:latest > www.enc.tar
sudo nerdctl load < www.enc.tar
```