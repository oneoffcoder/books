# REST-ful API

## Run

```bash
uvicorn main:app --reload
```

## Docker

```bash
docker build -t rest:local .
docker run --rm -p 8000:80 rest:local

docker tag rest:local localhost:5000/rest:latest
docker image push localhost:5000/rest:latest
docker rmi localhost:5000/rest:latest

sudo ctr-enc images pull --plain-http=true --all-platforms localhost:5000/rest:latest
sudo ctr-enc images layerinfo --platform linux/amd64 localhost:5000/rest:latest

sudo ctr-enc images encrypt --recipient jwe:public.pem --platform linux/amd64 localhost:5000/rest:latest localhost:5000/rest.enc:latest
sudo ctr-enc images layerinfo --platform linux/amd64 localhost:5000/rest.enc:latest

# won't work
sudo ctr-enc run --rm -p 8000:80 localhost:5000/rest.enc:latest

# need to install nerdctl: https://github.com/containerd/nerdctl/releases
# need to install plugins: https://github.com/containernetworking/plugins/releases
sudo nerdctl run --rm -p 8000:80 localhost:5000/rest.enc:latest

# save
sudo nerdctl save localhost:5000/rest.enc:latest > rest.enc.tar
sudo nerdctl load < rest.enc.tar

# compose
sudo nerdctl compose up
sudo nerdctl compose up -d
sudo nerdctl compose down
```